#!/usr/bin/env bash
# Set bash to 'debug' mode, it will exit on :
# -e 'error', -u 'undefined variable', -o ... 'error in pipeline', -x 'print commands',
set -e
set -u
set -o pipefail


# stage 10: ASR collect stats
# stage 11: ASR Training
# stage 12: Decoding
stage=12
stop_stage=13

# You have to create links in dump/extracted for the features you need.
#train_set=cgn_dutch_flemish_jasmin
#train_set=train_nonna_pp2fold
train_set=cgn_dutch_flemish_jasmin_nonnapp2fold
#train_set=cgn_flemish
valid_set="dev_s"
#test_sets="dev_s dev_t"
test_sets="dev_s dev_t test_hmi_native test_hmi_nonna test_read_native test_read_nonna"
# vocab=
nbpe=5000
bpe_train_text=

ngpu=4
pretrained_model=
ignore_init_mismatch=true
asr_config=conf/train_asr_streaming_conformer.yaml
asr_exp=exp/train_asr_conformer_cgn_dutch_flemish_jasmin_nonnapp2fold
#asr_exp=exp/train_asr_conformer_cgn_dutch_flemish
#asr_exp=exp/train_asr_conformer_cgn_fbank

#use_streaming=true
inference_nj=32
#inference_asr_model=train.loss_ctc.ave_10best.pth
inference_asr_model=train.loss.ave_10best.pth
#inference_asr_model=23epoch.pth
#inference_asr_model=16epoch.pth
inference_config=conf/decode_asr_default.yaml


lm_config=conf/train_lm.yaml
use_lm=false
use_wordlm=false

# speed perturbation related
# (train_set will be "${train_set}_sp" if speed_perturb_factors is specified)
speed_perturb_factors=""

./asr.sh                                            \
    --stage ${stage}                                   \
    --stop_stage ${stop_stage}                         \
    --nbpe ${nbpe}                                     \
    --bpe_train_text "${bpe_train_text}"               \
    --ngpu ${ngpu}                                     \
    --pretrained_model "${pretrained_model}"           \
    --ignore_init_mismatch ${ignore_init_mismatch}     \
    --lang noinfo                                      \
    --audio_format wav                                 \
    --feats_type fbank                                \
    --token_type bpe                                  \
    --use_lm ${use_lm}                                 \
    --use_word_lm ${use_wordlm}                        \
    --lm_config "${lm_config}"                         \
    --asr_config "${asr_config}"                       \
    --asr_exp "${asr_exp}"                             \
    --inference_config "${inference_config}"           \
    --train_set "${train_set}"                         \
    --valid_set "${valid_set}"                         \
    --test_sets "${test_sets}"                         \
    --speed_perturb_factors "${speed_perturb_factors}" \
    --asr_speech_fold_length 512                       \
    --asr_text_fold_length 150                         \
    --lm_fold_length 150                               \
    --lm_train_text "data/${train_set}/text"           \
    --inference_nj ${inference_nj}                     \
    --inference_asr_model "${inference_asr_model}"     \

